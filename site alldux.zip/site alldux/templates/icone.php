<head>
    <link rel="stylesheet" href="css/icone.css">
</head>

<div class="scene-wrapper">
    <div class="containericon">
        <div class="birds front">
            <div class="bird b1">
                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b2">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b3">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b4">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b5">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b6">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b7">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b8">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b9">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b10">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b11">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b12">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="birds back">
            <div class="bird b1">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b2">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b3">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b4">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b5">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b6">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b7">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b8">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b9">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b10">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b11">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
            <div class="bird b12">

                <div class="wing1">
                    <div class="wing2">
                        <div class="wing3"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="cloud big">
            <div class="circle c0"></div>
            <div class="circle c1"></div>
            <div class="circle c2"></div>
            <div class="circle c3"></div>
            <div class="circle c4"></div>
            <div class="circle c5"></div>
            <div class="circle c6"></div>
            <div class="circle c7"></div>
            <div class="circle c8"></div>
        </div>
        <div class="cloud small">
            <div class="circle c0"></div>
            <div class="circle c1"></div>
            <div class="circle c2"></div>
            <div class="circle c3"></div>
            <div class="circle c4"></div>
            <div class="circle c5"></div>
            <div class="circle c6"></div>
            <div class="circle c7"></div>
            <div class="circle c8"></div>
        </div>
        <div class="mountain2">
            <div class="backdrop"></div>
            <div class="zig zag0"></div>
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
            <div class="zig zag1"></div>
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
            <div class="zig zag2"></div>
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
            <div class="zig zag3"></div>
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
            <div class="zig zag4"></div>
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="range">
            <div class="r1"></div>
            <div class="r2"></div>
            <div class="r3"></div>
            <div class="r4"></div>
            <div class="r5"></div>
            <div class="r6"></div>
            <div class="r7"></div>
        </div>
        <div class="tree2 tree2Back tree21">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree22">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree23">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree24">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree25">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree26">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree27">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Back tree28">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tower">
            <div class="shadow"></div>
            <div class="flagPole"></div>
            <div class="roof1"></div>
            <div class="roof2"></div>
            <div class="wall">
                <div class="w1"></div>
                <div class="w2"></div>
                <div class="w3"></div>
                <div class="w4"></div>
                <div class="w5"></div>
            </div>
            <div class="legs">
                <div class="left"></div>
                <div class="right"></div>
                <div class="support1">
                    <div class="criss"></div>
                    <div class="cross"></div>
                    <div class="flat"></div>
                </div>
                <div class="support2">
                    <div class="criss"></div>
                    <div class="cross"></div>
                    <div class="flat"></div>
                </div>
            </div>
            <div class="railing">
                <div class="top"></div>
                <div class="bot1"></div>
                <div class="bot2"></div>
                <div class="r1"></div>
                <div class="r2"></div>
                <div class="r3"></div>
                <div class="r4"></div>
                <div class="r5"></div>
                <div class="r6"></div>
                <div class="r7"></div>
                <div class="r8"></div>
                <div class="r9"></div>
            </div>
        </div>
        <div class="tree2 tree2Mid tree21">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Mid tree22">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Mid tree23">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Mid tree24">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Mid tree25">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Front tree21">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Front tree22">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Front tree23">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
        <div class="tree2 tree2Front tree24">
            <div class="top"></div>
            <div class="mid"></div>
            <div class="bot"></div>
            <div class="base"></div>
        </div>
    </div>
</div>